Contains location and location server exe

---for client
leave location empty for GET request
--- for Server
Save log while server is running
and provide path to load and save a file before starting server